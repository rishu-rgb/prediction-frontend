import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Rectangle, Polyline, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

// Manipur districts with their approximate center coordinates
const MANIPUR_DISTRICTS = {
  'Bishnupur': { center: [24.6167, 93.7667], zoom: 11 },
  'Chandel': { center: [24.3167, 94.0167], zoom: 10 },
  'Churachandpur': { center: [24.3333, 93.6667], zoom: 10 },
  'ImphalEast': { center: [24.7667, 93.9667], zoom: 11 },
  'ImphalWest': { center: [24.8167, 93.9167], zoom: 11 },
  'Jiribam': { center: [24.8083, 93.1167], zoom: 11 },
  'Kakching': { center: [24.4833, 93.9833], zoom: 11 },
  'Kamjong': { center: [24.8333, 94.4167], zoom: 10 },
  'Kangpokpi': { center: [25.2167, 93.9833], zoom: 10 },
  'Noney': { center: [24.9500, 93.6833], zoom: 10 },
  'Pherzawl': { center: [24.1667, 93.1167], zoom: 10 },
  'Senapati': { center: [25.2667, 94.0167], zoom: 10 },
  'Tamenglong': { center: [24.9833, 93.4833], zoom: 10 },
  'Tengnoupal': { center: [24.3167, 94.1333], zoom: 10 },
  'Thoubal': { center: [24.6333, 94.0000], zoom: 11 },
  'Ukhrul': { center: [25.0500, 94.3667], zoom: 10 }
};

// Component to handle map view changes
function MapViewController({ center, zoom }) {
  const map = useMap();
  
  useEffect(() => {
    if (center && zoom) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  
  return null;
}

// Component to render risk cells and detect road intersections
function RiskCellsLayer({ cells, onRoadWarnings }) {
  const map = useMap();
  
  useEffect(() => {
    if (!cells || cells.length === 0) return;
    
    // Simulate road intersection detection
    // In a real system, this would query OSM Overpass API for actual roads
    const warnings = [];
    const highRiskCells = cells.filter(cell => cell.risk_percentage >= 30);
    
    if (highRiskCells.length > 0) {
      // Simulate finding affected roads
      warnings.push({
        type: cell => cell.risk_percentage >= 60 ? 'landslide' : 'flood',
        message: 'Major roads may be affected in high-risk zones. Alternative routes recommended.',
        affectedAreas: highRiskCells.length
      });
    }
    
    onRoadWarnings(warnings);
  }, [cells, onRoadWarnings]);
  
  return null;
}

function DisasterWarningSystem() {
  const [selectedState, setSelectedState] = useState('Manipur');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [riskCells, setRiskCells] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [roadWarnings, setRoadWarnings] = useState([]);
  const [mapCenter, setMapCenter] = useState([24.8, 93.95]);
  const [mapZoom, setMapZoom] = useState(9);

  // Fetch disaster prediction data from backend
  const fetchDisasterData = async (district) => {
    setLoading(true);
    setError(null);
    setRiskCells([]);
    setRoadWarnings([]);
    
    try {
      // Remove spaces from district name for API call
      const districtParam = district.replace(/\s+/g, '');
      const response = await fetch(`/api/v1/status?district=${districtParam}`);
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      setRiskCells(data);
      
      // Center map on selected district
      if (MANIPUR_DISTRICTS[districtParam]) {
        setMapCenter(MANIPUR_DISTRICTS[districtParam].center);
        setMapZoom(MANIPUR_DISTRICTS[districtParam].zoom);
      }
    } catch (err) {
      setError(`Failed to fetch data: ${err.message}`);
      console.error('Error fetching disaster data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Handle district selection
  const handleDistrictChange = (e) => {
    const district = e.target.value;
    setSelectedDistrict(district);
    
    if (district) {
      fetchDisasterData(district);
    } else {
      setRiskCells([]);
      setRoadWarnings([]);
      setMapCenter([24.8, 93.95]);
      setMapZoom(9);
    }
  };

  // Determine color based on risk percentage
  const getRiskColor = (riskPercentage) => {
    if (riskPercentage < 30) return '#22c55e'; // Green
    if (riskPercentage < 60) return '#f97316'; // Orange
    return '#ef4444'; // Red
  };

  // Get risk level text
  const getRiskLevel = (riskPercentage) => {
    if (riskPercentage < 30) return 'Low Risk';
    if (riskPercentage < 60) return 'Moderate Risk';
    return 'High Risk';
  };

  // Format timestamp
  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'medium',
      timeStyle: 'short'
    });
  };

  // Calculate statistics
  const stats = {
    total: riskCells.length,
    highRisk: riskCells.filter(c => c.risk_percentage >= 60).length,
    moderateRisk: riskCells.filter(c => c.risk_percentage >= 30 && c.risk_percentage < 60).length,
    lowRisk: riskCells.filter(c => c.risk_percentage < 30).length
  };

  return (
    <div style={{ fontFamily: 'system-ui, -apple-system, sans-serif', height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <header style={{ 
        background: 'linear-gradient(135deg, #1e40af 0%, #3b82f6 100%)',
        color: 'white',
        padding: '1.5rem 2rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
      }}>
        <h1 style={{ margin: 0, fontSize: '1.75rem', fontWeight: 600 }}>
          🇮🇳 AI-based Natural Disaster Early Warning System – India
        </h1>
        <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.95rem', opacity: 0.95 }}>
          Real-time Predictive Analytics for Disaster Management
        </p>
      </header>

      {/* Controls Panel */}
      <div style={{ 
        padding: '1.25rem 2rem',
        background: '#f8fafc',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        gap: '1.5rem',
        alignItems: 'center',
        flexWrap: 'wrap'
      }}>
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <label style={{ fontWeight: 500, color: '#475569' }}>State:</label>
          <select 
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            style={{
              padding: '0.5rem 1rem',
              border: '1px solid #cbd5e1',
              borderRadius: '6px',
              fontSize: '0.95rem',
              background: 'white',
              cursor: 'pointer'
            }}
          >
            <option value="Manipur">Manipur</option>
            {/* Future states will be added here */}
          </select>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <label style={{ fontWeight: 500, color: '#475569' }}>District:</label>
          <select 
            value={selectedDistrict}
            onChange={handleDistrictChange}
            style={{
              padding: '0.5rem 1rem',
              border: '1px solid #cbd5e1',
              borderRadius: '6px',
              fontSize: '0.95rem',
              background: 'white',
              cursor: 'pointer',
              minWidth: '180px'
            }}
          >
            <option value="">Select District</option>
            {Object.keys(MANIPUR_DISTRICTS).sort().map(district => (
              <option key={district} value={district}>
                {district.replace(/([A-Z])/g, ' $1').trim()}
              </option>
            ))}
          </select>
        </div>

        {loading && (
          <div style={{ color: '#3b82f6', fontSize: '0.9rem', fontWeight: 500 }}>
            ⏳ Loading prediction data...
          </div>
        )}

        {stats.total > 0 && (
          <div style={{ 
            marginLeft: 'auto',
            display: 'flex',
            gap: '1rem',
            fontSize: '0.85rem',
            fontWeight: 500
          }}>
            <span style={{ color: '#64748b' }}>Total Cells: {stats.total}</span>
            <span style={{ color: '#ef4444' }}>High: {stats.highRisk}</span>
            <span style={{ color: '#f97316' }}>Moderate: {stats.moderateRisk}</span>
            <span style={{ color: '#22c55e' }}>Low: {stats.lowRisk}</span>
          </div>
        )}
      </div>

      {/* Road Warnings */}
      {roadWarnings.length > 0 && (
        <div style={{
          margin: '0 2rem',
          marginTop: '1rem',
          padding: '1rem',
          background: '#fef3c7',
          border: '1px solid #fbbf24',
          borderRadius: '8px',
          display: 'flex',
          gap: '0.75rem',
          alignItems: 'start'
        }}>
          <span style={{ fontSize: '1.25rem' }}>⚠️</span>
          <div>
            <strong style={{ color: '#92400e' }}>Road Safety Alert:</strong>
            <p style={{ margin: '0.25rem 0 0 0', color: '#78350f', fontSize: '0.9rem' }}>
              {roadWarnings[0].message} {stats.highRisk} high-risk zones detected.
            </p>
            <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.85rem', color: '#78350f' }}>
              <strong>Recommendations:</strong> Use alternative routes. For landslide zones, road blockages likely. 
              For flood zones, seek higher elevation areas marked in green.
            </p>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div style={{
          margin: '0 2rem',
          marginTop: '1rem',
          padding: '1rem',
          background: '#fee2e2',
          border: '1px solid #ef4444',
          borderRadius: '8px',
          color: '#991b1b'
        }}>
          ❌ {error}
        </div>
      )}

      {/* Map Container */}
      <div style={{ flex: 1, position: 'relative', margin: '1rem 2rem 2rem 2rem', borderRadius: '8px', overflow: 'hidden', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          style={{ height: '100%', width: '100%' }}
          zoomControl={true}
        >
          {/* OpenStreetMap Base Layer */}
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {/* Map View Controller */}
          <MapViewController center={mapCenter} zoom={mapZoom} />
          
          {/* Risk Cells Layer */}
          <RiskCellsLayer cells={riskCells} onRoadWarnings={setRoadWarnings} />
          
          {/* Render Risk Rectangles */}
          {riskCells.map((cell, index) => {
            const bounds = [
              [cell.bounds.minLat, cell.bounds.minLon],
              [cell.bounds.maxLat, cell.bounds.maxLon]
            ];
            const color = getRiskColor(cell.risk_percentage);
            
            return (
              <Rectangle
                key={index}
                bounds={bounds}
                pathOptions={{
                  color: color,
                  fillColor: color,
                  fillOpacity: 0.4,
                  weight: 2
                }}
              >
                <Popup>
                  <div style={{ fontSize: '0.9rem' }}>
                    <strong style={{ color: color }}>{getRiskLevel(cell.risk_percentage)}</strong>
                    <div style={{ marginTop: '0.5rem' }}>
                      <strong>Risk:</strong> {cell.risk_percentage}%
                    </div>
                    <div style={{ marginTop: '0.25rem', fontSize: '0.85rem', color: '#64748b' }}>
                      <strong>Updated:</strong><br/>{formatTimestamp(cell.updated_at)}
                    </div>
                    {cell.risk_percentage >= 60 && (
                      <div style={{ marginTop: '0.5rem', padding: '0.5rem', background: '#fee2e2', borderRadius: '4px', fontSize: '0.85rem' }}>
                        ⚠️ High risk area. Roads may be blocked.
                      </div>
                    )}
                    {cell.risk_percentage >= 30 && cell.risk_percentage < 60 && (
                      <div style={{ marginTop: '0.5rem', padding: '0.5rem', background: '#fef3c7', borderRadius: '4px', fontSize: '0.85rem' }}>
                        ⚡ Moderate risk. Stay alert.
                      </div>
                    )}
                  </div>
                </Popup>
              </Rectangle>
            );
          })}
        </MapContainer>

        {/* Legend */}
        <div style={{
          position: 'absolute',
          bottom: '20px',
          right: '20px',
          background: 'white',
          padding: '1rem',
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
          zIndex: 1000
        }}>
          <div style={{ fontWeight: 600, marginBottom: '0.75rem', fontSize: '0.9rem' }}>Risk Legend</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.85rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{ width: '20px', height: '20px', background: '#22c55e', border: '2px solid #16a34a', borderRadius: '3px' }}></div>
              <span>Low Risk (&lt;30%)</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{ width: '20px', height: '20px', background: '#f97316', border: '2px solid #ea580c', borderRadius: '3px' }}></div>
              <span>Moderate Risk (30-59%)</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{ width: '20px', height: '20px', background: '#ef4444', border: '2px solid #dc2626', borderRadius: '3px' }}></div>
              <span>High Risk (≥60%)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DisasterWarningSystem;
